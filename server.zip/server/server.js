const express = require('express');
const mysql = require('mysql');
const app = express();
const cors = require('cors');

app.use(cors());


app.use(express.json());

app.listen(3000, () => {
    console.log("Server prendido");
});

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '12345',
    database: 'escuela'
});

connection.connect((err) => {
    if (err) {
        console.error("Error de conexión: ", err);
    }
    console.log("Conexion realizada!");
});

// Endpoint para obtener todos los alumnos
app.get('/alumnos', (req, res) => {
    connection.query("SELECT * FROM alumnos", (err, rows) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(rows);
        res.json(rows);
    });
});

// Endpoint para agregar un nuevo alumno
app.post('/alumnos', (req, res) => {
    const { nombre, edad } = req.body;
    const query = `INSERT INTO alumnos (nombre, edad) VALUES (?, ?)`;

    connection.query(query, [nombre, edad], (err, result) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(result);
        res.status(201).send("Alumno creado exitosamente");
    });
});

// Endpoint para actualizar un alumno
app.put('/alumnos/:id', (req, res) => {
    const { nombre, edad } = req.body;
    const query = `UPDATE alumnos SET nombre = ?, edad = ? WHERE alumno_id = ?`;

    connection.query(query, [nombre, edad, req.params.id], (err, result) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(result);
        res.status(200).send("Alumno actualizado correctamente");
    });
});

// Endpoint para eliminar un alumno
app.delete('/alumnos/:id', (req, res) => {
    const query = `DELETE FROM alumnos WHERE alumno_id = ?`;

    connection.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error("Error de conexión: ", err);
            res.status(500).send("Error interno del servidor");
        }

        console.log(result);
        res.status(200).send("Alumno eliminado exitosamente");
    });
});


