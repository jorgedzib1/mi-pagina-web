// Importa las dependencias
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// Configura la aplicación Express
const app = express();
app.use(express.json());
app.use(cors());

// Conexión a la base de datos MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/Escuela1', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Error de conexión a MongoDB:'));
db.once('open', () => {
  console.log('Conectado a la base de datos MongoDB');
});

// Define los esquemas del modelo
const califSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: [true, 'El userId es requerido']
  },
  materiaId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Materia',
    required: [true, 'El materiaId es requerido']
  },
  calificacion: {
    type: Number,
    required: [true, 'La calificación es requerida']
  }
});

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'El nombre es requerido']
  },
  email: {
    type: String,
    required: [true, 'El email es requerido']
  },
  age: {
    type: Number,
    required: [true, 'La edad es requerida']
  },
  password: {
    type: String,
    required: [true, 'La contraseña es requerida']
  }
});

const materSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: [true, 'El nombre de la materia es requerido']
  }
});

// Define los modelos
const Calificacion = mongoose.model('Calificacion', califSchema);
const Usuario = mongoose.model('Usuario', userSchema);
const Materia = mongoose.model('Materia', materSchema);

// Ruta GET para obtener todas las calificaciones con información adicional
app.get('/calificacions', async (req, res) => {
  try {
    const calificaciones = await Calificacion.find();

    const nuevasCalificaciones = await Promise.all(
      calificaciones.map(async (element) => {
        const userInfo = await Usuario.findById(element.userId);
        const materInfo = await Materia.findById(element.materiaId);
        return {
          userInfo,
          materiaInfo: materInfo.nombre,
          calificacion: element.calificacion
        };
      })
    );

    res.json(nuevasCalificaciones);
  } catch (error) {
    console.error('Error al obtener calificaciones:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta POST para crear una nueva calificación
app.post('/calificacions', async (req, res) => {
  try {
    const nuevaCalificacion = new Calificacion(req.body);
    await nuevaCalificacion.save();
    res.status(201).json(nuevaCalificacion);
  } catch (error) {
    console.error('Error al crear calificación:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta PUT para actualizar una calificación existente
app.put('/calificacions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { userId, materiaId, calificacion } = req.body;
    const calificacionActualizada = await Calificacion.findByIdAndUpdate(id, { userId, materiaId, calificacion }, { new: true });
    res.json(calificacionActualizada);
  } catch (error) {
    console.error('Error al actualizar calificación:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta DELETE para eliminar una calificación
app.delete('/calificacions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await Calificacion.findByIdAndDelete(id);
    res.json({ message: 'Calificación eliminada correctamente' });
  } catch (error) {
    console.error('Error al eliminar calificación:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Rutas CRUD para Usuario

// Ruta GET para obtener todos los usuarios
app.get('/usuarios', async (req, res) => {
  try {
    const usuarios = await Usuario.find();
    res.json(usuarios);
  } catch (error) {
    console.error('Error al obtener usuarios:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta POST para crear un nuevo usuario
app.post('/usuarios', async (req, res) => {
  try {
    const nuevoUsuario = new Usuario(req.body);
    await nuevoUsuario.save();
    res.status(201).json(nuevoUsuario);
  } catch (error) {
    console.error('Error al crear usuario:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta PUT para actualizar un usuario existente
app.put('/usuarios/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, age, password } = req.body;
    const usuarioActualizado = await Usuario.findByIdAndUpdate(id, { name, email, age, password }, { new: true });
    res.json(usuarioActualizado);
  } catch (error) {
    console.error('Error al actualizar usuario:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Ruta DELETE para eliminar un usuario
app.delete('/usuarios/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await Usuario.findByIdAndDelete(id);
    res.json({ message: 'Usuario eliminado correctamente' });
  } catch (error) {
    console.error('Error al eliminar usuario:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Inicia el servidor
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
