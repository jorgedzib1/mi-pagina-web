import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import "./TablaReprobados.css";

const TablaReprobados = () => {
  const [reprobados, setReprobados] = useState([]);
  const [filtro, setFiltro] = useState('');

  useEffect(() => {
    const obtenerReprobados = async () => {
      try {
        const response = await axios.get('http://localhost:3000/calificacions');
        const reprobadosData = response.data.filter(calif => calif.calificacion < 6);
        setReprobados(reprobadosData);
      } catch (error) {
        console.error('Error al obtener reprobados:', error);
      }
    };

    obtenerReprobados();
  }, []);

  const handleInputChange = (event) => {
    setFiltro(event.target.value);
  };

  const reprobadosFiltrados = reprobados.filter(reprobado =>
    reprobado.userInfo && reprobado.userInfo.name.toLowerCase().includes(filtro.toLowerCase()) ||
    reprobado.materiaInfo.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className="table-card">
      <div className="button-container">
        <Link to="/home" className="button">Volver a home</Link>
      </div>
      <div className="table-container">
        <h2 className="table-title font-Ocean">Tabla De Reprobados</h2>
        <input
          type="text"
          className="search-input"
          placeholder="Buscar"
          value={filtro}
          onChange={handleInputChange}
          style={{borderRadius: '20px'}}
        />
        <table className="table">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Materia</th>
              <th>Calificación</th>
            </tr>
          </thead>
          <tbody>
            {reprobadosFiltrados.map(reprobado => (
              <tr key={reprobado._id}>
                <td>{reprobado.userInfo ? reprobado.userInfo.name : 'Sin nombre'}</td>
                <td>{reprobado.materiaInfo}</td>
                <td>{reprobado.calificacion}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TablaReprobados;
