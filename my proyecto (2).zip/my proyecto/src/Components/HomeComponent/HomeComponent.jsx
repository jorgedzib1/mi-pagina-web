import React from 'react';
import { Link } from 'react-router-dom';

class HomeComponent extends React.Component {
  render() {
    return (
      <div className="bg-gradient-to-r from-blue-200 to-blue-400 rounded-lg p-8 shadow-md text-center">
        <h1 className="text-4xl font-bold text-white mb-6">Bienvenido a mi página web</h1>
        <p className="text-lg text-white mb-8">¡Hola! Esta es mi página. ¡Espero que te guste!</p>

        <div className="flex justify-center space-x-4">
          <Link to="/registro" className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition duration-300 ease-in-out">Regístrate</Link>
          <Link to="/login" className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75 transition duration-300 ease-in-out">Inicia Sesión</Link>
        </div>
      </div>
    );
  }
}

export default HomeComponent;
