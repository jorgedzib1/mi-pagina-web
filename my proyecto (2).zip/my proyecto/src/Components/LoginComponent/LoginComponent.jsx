import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';

export default function LoginComponent() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginMessage, setLoginMessage] = useState("");

  // Nuevo estado para almacenar el valor del campo de correo electrónico
  const [emailValue, setEmailValue] = useState("");

  // Función para convertir el texto del campo de correo electrónico en voz
  const speakUsername = () => {
    const usernameMessage = new SpeechSynthesisUtterance(emailValue);
    window.speechSynthesis.speak(usernameMessage);
  };

  // Efecto para ejecutar speakUsername cada vez que cambie el valor del campo de correo electrónico
  useEffect(() => {
    speakUsername();
  }, [emailValue]);

  const handleLogin = () => {
    const credentials = {
      email: email,
      password: password
    };

    fetch("http://localhost:3000/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(credentials)
    })
      .then(response => {
        if (response.ok) {
          setLoginMessage("Haz iniciado sesión");
          window.location.href="/tabla";
          
        } else {
          setLoginMessage("Error al iniciar sesión. Verifica tus datos.");
        }
        return response.json();
      })
      .then(data => {
        console.log(data); // Puedes hacer algo con los datos si es necesario
      })
      .catch(error => {
        console.error("Error:", error);
        setLoginMessage("");
      });
  };

  const handleRegister = () => {
    // Aquí puedes redirigir al usuario a la página de registro
    console.log("Redirigir al usuario a la página de registro");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-blue-100">
      <div className="bg-white p-8 rounded shadow-md w-80 border border-blue-500">
        <h2 className="text-2xl font-semibold mb-4 text-blue-600">Inicio de sesión</h2>
        <div className="mb-4">
          <div className="flex items-center border-b border-blue-500 py-2">
            <svg
              className="w-6 h-6 mr-3 text-blue-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 14l9-5-9-5-9 5 9 5z"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M12 14l9-5-9-5-9 5 9 5z"
              />
            </svg>
            <input
              type="email"
              placeholder="Correo electrónico"
              className="w-full outline-none focus:outline-none text-blue-600"
              value={email}
              onChange={e => {
                setEmail(e.target.value);
                setEmailValue(e.target.value); // Actualizar el valor del campo de correo electrónico
              }}
            />
          </div>
        </div>
        <div className="mb-6">
          <div className="flex items-center border-b border-blue-500 py-2">
            <svg
              className="w-6 h-6 mr-3 text-blue-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M4 15s1 0 1.5 0S7 15 9 15s7 0 7.5 0S18 15 18 15"
              />
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M5 12V9a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v3m-9 4h6m-3 4h3"
              />
            </svg>
            <input
              type="password"
              placeholder="Contraseña"
              className="w-full outline-none focus:outline-none text-blue-600"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>
        </div>
        <Link to="/tabla" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded w-full mb-4" onClick={handleLogin}>
          Iniciar sesión
        </Link>
        {loginMessage && (
          <p className="mt-4 text-center text-red-500">{loginMessage}</p>
        )}
        <div className="text-center">
          <p>¿No tienes cuenta? <Link to="/registro" className="text-blue-600">Regístrate</Link></p>
        </div>
      </div>
    </div>
  );
}
