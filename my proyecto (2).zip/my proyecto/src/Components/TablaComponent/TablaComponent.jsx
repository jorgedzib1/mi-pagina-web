import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom'; // Importa el componente Link
import './TablaComponent.css';

function TablaComponent() {
  const [alumnos, setAlumnos] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [alumnoSeleccionado, setAlumnoSeleccionado] = useState(null);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevoCorreo, setNuevoCorreo] = useState('');
  const [nuevaContraseña, setNuevaContraseña] = useState('');
  const [nuevaEdad, setNuevaEdad] = useState('');
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    async function fetchAlumnos() {
      try {
        const response = await fetch('http://localhost:3000/usuarios');
        if (!response.ok) {
          throw new Error('Error al obtener los datos');
        }
        const data = await response.json();
        setAlumnos(data);
      } catch (error) {
        console.error('Error:', error);
      }
    }
    fetchAlumnos();
  }, []);

  const handleUpdateButtonClick = (alumno) => {
    setAlumnoSeleccionado(alumno);
    setNuevoNombre(alumno.name);
    setNuevoCorreo(alumno.email);
    setNuevaContraseña(alumno.password);
    setNuevaEdad(alumno.age);
    setModalOpen(true);
    setConfirmModalOpen(false);
  };

  const handleDeleteButtonClick = async (alumnoId) => {
    setAlumnoSeleccionado(alumnoId);
    setConfirmModalOpen(true);
    setModalOpen(false);
  };

  const confirmDelete = async () => {
    try {
      const response = await fetch(`http://localhost:3000/usuarios/${alumnoSeleccionado}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Error al eliminar el alumno');
      }

      const updatedAlumnos = alumnos.filter((alumno) => alumno._id !== alumnoSeleccionado);
      setAlumnos(updatedAlumnos);
    } catch (error) {
      console.error('Error:', error);
    }
    setConfirmModalOpen(false);
  };

  const handleUpdate = async () => {
    try {
      const response = await fetch(`http://localhost:3000/usuarios/${alumnoSeleccionado._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: nuevoNombre,
          email: nuevoCorreo,
          password: nuevaContraseña,
          age: nuevaEdad,
        }),
      });

      if (!response.ok) {
        throw new Error('Error al actualizar el alumno');
      }

      const updatedAlumno = await response.json();
      setAlumnos((prevAlumnos) =>
        prevAlumnos.map((alumno) => (alumno._id === updatedAlumno._id ? updatedAlumno : alumno))
      );
      setModalOpen(false);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const filteredAlumnos = alumnos.filter((alumno) => {
    return alumno.name.toLowerCase().includes(searchText.toLowerCase()) || alumno._id.toLowerCase().includes(searchText.toLowerCase());
  });

  return (
    <div className="container mx-auto py-4">
      <h2 className="text-2xl font-bold mb-4">Lista De Alumnos</h2>
      <Link to="/tablareprobados" className="button">Ir A tabla Reprobados</Link> {/* Aquí se agrega el botón para ir a /tablareprobados */}
      <input
        type="text"
        placeholder="Buscar"
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
        className="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:border-blue-500 mb-4"
      />
      <table className="table-auto w-full"></table>
      <table className="table-auto w-full">
        <thead>
          <tr>
            <th className="px-4 py-2 bg-blue-500 text-white font-bold">Nombre</th>
            <th className="px-4 py-2 bg-blue-500 text-white font-bold">Correo</th>
            <th className="px-4 py-2 bg-blue-500 text-white font-bold">Contraseña</th>
            <th className="px-4 py-2 bg-blue-500 text-white font-bold">Edad</th>
            <th className="px-4 py-2 bg-blue-500 text-white font-bold">Acciones</th>
          </tr>
        </thead>
        <tbody>
          {filteredAlumnos.map((alumno, index) => (
            <tr key={alumno._id} className={index % 2 === 0 ? 'bg-gray-100' : ''}>
              <td className="border px-4 py-2">{alumno.name}</td>
              <td className="border px-4 py-2">{alumno.email}</td>
              <td className="border px-4 py-2">*****</td>
              <td className="border px-4 py-2">{alumno.age}</td>
              <td className="border px-4 py-2">
                <button
                  type="button"
                  className="btn-actualizar bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded mr-2"
                  onClick={() => handleUpdateButtonClick(alumno)}
                >
                  Actualizar
                </button>
                <button
                  className="btn-eliminar bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded"
                  onClick={() => handleDeleteButtonClick(alumno._id)}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modales */}
      {modalOpen && (
        <div className="modal-overlay" onClick={() => setModalOpen(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2 className="modal-title font-bold">Actualizar Alumno</h2>
            <Link to="/tablareprobados" className="button">Ir A tabla Reprobados</Link>
            <input type="text" value={nuevoNombre} onChange={(e) => setNuevoNombre(e.target.value)} placeholder="Nombre" className="modal-input" />
            <input type="text" value={nuevoCorreo} onChange={(e) => setNuevoCorreo(e.target.value)} placeholder="Correo" className="modal-input" />
            <input type="text" value={nuevaContraseña} onChange={(e) => setNuevaContraseña(e.target.value)} placeholder="Contraseña" className="modal-input" />
            <input type="number" value={nuevaEdad} onChange={(e) => setNuevaEdad(e.target.value)} placeholder="Edad" className="modal-input" />
            <button className="btn-actualizar bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded mr-2" onClick={handleUpdate}>
              Actualizar
            </button>
            <button className="btn-cancelar bg-gray-500 hover:bg-gray-700 text-white font-bold py-1 px-2 rounded" onClick={() => setModalOpen(false)}>
              Cerrar
            </button>
          </div>
        </div>
      )}

      {confirmModalOpen && (
        <div className="modal-overlay" onClick={() => setConfirmModalOpen(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2 className="modal-title font-bold">¿Estás seguro de eliminar este alumno?</h2>
            <button className="btn-eliminar bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded mr-2" onClick={confirmDelete}>
              Sí
            </button>
            <button className="btn-cancelar bg-gray-500 hover:bg-gray-700 text-white font-bold py-1 px-2 rounded" onClick={() => setConfirmModalOpen(false)}>
              No
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default TablaComponent;
