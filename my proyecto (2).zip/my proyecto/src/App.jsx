import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import LoginComponent from './Components/LoginComponent/LoginComponent';
import RegistroComponent from './Components/RegistroComponent/RegistroComponent';
import TablaComponent from './Components/TablaComponent/TablaComponent';
import TablaReprobados from './Components/TablaReprobados/TablaReprobados';
import HomeComponent from './Components/HomeComponent/HomeComponent';


function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<HomeComponent/>} />
        <Route path="/home" element={<HomeComponent/>} />
        <Route path="/login" element={<LoginComponent/>} />
        <Route path="/registro" element={<RegistroComponent/>} />
        <Route path="/tabla" element={<TablaComponent/>} />
        <Route path="/tablareprobados" element={<TablaReprobados/>} />

        
      </Routes>
    </Router>
  );
}

export default App;